import React from "react";

import React from "react";

// Gestión global de qué carta está mostrando su descripción
let activeCardId = null;

class Card extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isHovered: false,
      isDescriptionVisible: false
    };
  }

  componentDidMount() {
    // Al montar el componente, nos suscribimos a los clics globales
    document.addEventListener('click', this.handleGlobalClick);
  }

  componentWillUnmount() {
    // Limpieza al desmontar
    document.removeEventListener('click', this.handleGlobalClick);
  }

  handleMouseEnter = () => {
    this.setState({ isHovered: true });
  };

  handleMouseLeave = () => {
    this.setState({ isHovered: false });
  };

  handleClick = (e) => {
    // Al hacer clic en la carta, mostramos su descripción
    e.stopPropagation(); // Evitamos que el clic llegue al documento
    
    // Si esta carta ya estaba activa, desactivamos todas
    if (activeCardId === this.props.id) {
      activeCardId = null;
      this.setState({ isDescriptionVisible: false });
    } else {
      // Activamos esta carta
      activeCardId = this.props.id;
      this.setState({ isDescriptionVisible: true });
      
      // Notificar a todas las demás cartas que deberían ocultarse
      document.dispatchEvent(new CustomEvent('card-activated', { 
        detail: { cardId: this.props.id } 
      }));
    }
  };

  handleGlobalClick = (e) => {
    // Si se hace clic fuera de esta carta, ocultamos su descripción
    if (this.state.isDescriptionVisible) {
      this.setState({ isDescriptionVisible: false });
    }
  };
  
  handleCardActivated = (e) => {
    // Si otra carta fue activada, ocultamos nuestra descripción
    if (e.detail.cardId !== this.props.id && this.state.isDescriptionVisible) {
      this.setState({ isDescriptionVisible: false });
    }
  };

  handleDragStart = (e) => {
    e.dataTransfer.setData("cardId", this.props.id);
    e.dataTransfer.setData("cardType", this.props.type);
    e.dataTransfer.setData("cardName", this.props.name || "Sin nombre");
    e.dataTransfer.setData("cardRarity", this.props.rarity || "Común");
  };  componentDidUpdate(prevProps, prevState) {
    // Si cambiamos de estado, suscribirse al evento de activación de otra carta
    if (this.state.isDescriptionVisible && !prevState.isDescriptionVisible) {
      document.addEventListener('card-activated', this.handleCardActivated);
    } else if (!this.state.isDescriptionVisible && prevState.isDescriptionVisible) {
      document.removeEventListener('card-activated', this.handleCardActivated);
    }
  }

  render() {
    const { isHovered, isDescriptionVisible } = this.state;
    const scale = isHovered ? 1.1 : 1;
    const isSmall = this.props.isSmall;
    
    return (
      <div style={{ position: 'relative', zIndex: (isHovered || isDescriptionVisible) ? 100 : 1 }}>
        <div
          draggable
          onDragStart={this.handleDragStart}
          onMouseEnter={this.handleMouseEnter}
          onMouseLeave={this.handleMouseLeave}
          onClick={this.handleClick}
          style={{            margin: '3px',
            padding: isSmall ? '5px' : '10px',
            backgroundColor: this.props.color,
            border: '2px solid #333',
            borderRadius: '8px',
            cursor: 'grab',
            width: isSmall ? '80px' : '120px',
            height: isSmall ? '60px' : '160px',
            textAlign: 'center',
            color: 'white',
            fontWeight: 'bold',
            fontSize: isSmall ? '12px' : '14px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
            transition: 'transform 0.3s ease',
            transform: `scale(${scale})`,
            boxShadow: isHovered ? '0 10px 20px rgba(0,0,0,0.4)' : '0 4px 8px rgba(0,0,0,0.2)'
          }}
        >          <div style={{ 
            fontSize: this.props.isSmall ? '12px' : '16px', 
            marginBottom: this.props.isSmall ? '2px' : '5px'
          }}>
            {this.props.type || "🃏"}{this.props.id}
          </div>
          <div style={{ 
            fontSize: this.props.isSmall ? '8px' : '12px', 
            fontStyle: 'italic',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            width: '100%'
          }}>
            {this.props.name || "Sin nombre"}
          </div>
          {!this.props.isSmall && (
            <div style={{ 
              fontSize: '10px', 
              backgroundColor: 'rgba(0, 0, 0, 0.3)',
              padding: '3px', 
              borderRadius: '3px',
              marginTop: '5px' 
            }}>
              {this.props.rarity || "Común"}
            </div>
          )}
        </div>          {/* Descripción que aparece al hacer hover o clic */}
        {(isHovered || isDescriptionVisible) && this.props.description && (          <div 
            onClick={(e) => e.stopPropagation()} // Para evitar que cerrar al hacer clic en la descripción
            style={{
            position: 'absolute',
            top: this.props.isSmall ? '65px' : '-80px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: 'rgba(0, 0, 0, 0.9)',
            color: 'white',
            padding: '15px',
            borderRadius: '8px',
            width: '250px',
            maxHeight: '300px',
            fontSize: '13px',
            zIndex: 1000,
            boxShadow: '0 5px 15px rgba(0,0,0,0.5)',
            textAlign: 'left',
            pointerEvents: 'auto', // Esto permite interactuar con la descripción
            overflowY: 'auto', // Permite scroll vertical dentro de la descripción si es muy larga
            lineHeight: '1.4'
          }}>            <div style={{ 
              fontWeight: 'bold', 
              marginBottom: '8px',
              fontSize: '16px',
              textAlign: 'center',
              borderBottom: '1px solid rgba(255, 255, 255, 0.3)',
              paddingBottom: '6px'
            }}>
              {this.props.name}
            </div>
            <div style={{ 
              fontSize: '12px', 
              color: '#aaa', 
              marginBottom: '10px',
              textAlign: 'center'
            }}>
              {this.props.rarity}
            </div>
            <div style={{ textAlign: 'justify' }}>
              {this.props.description}
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default Card;
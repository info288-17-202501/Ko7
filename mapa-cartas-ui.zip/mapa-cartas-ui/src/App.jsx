import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

const HEX_SIZE = 40;
const HEX_WIDTH = HEX_SIZE * Math.sqrt(3);
const HEX_HEIGHT = HEX_SIZE * 2;
const HEX_HORIZ_SPACING = HEX_WIDTH;
const HEX_VERT_SPACING = HEX_HEIGHT * 0.75;
const GRID_RADIUS = 4;
const CARD_COUNT = 6;

function generateHexGrid(radius) {
  const coords = [];
  for (let q = -radius; q <= radius; q++) {
    const r1 = Math.max(-radius, -q - radius);
    const r2 = Math.min(radius, -q + radius);
    for (let r = r1; r <= r2; r++) {
      coords.push({ q, r });
    }
  }
  return coords;
}

function getHexPoints(size) {
  const angle_deg = 60;
  const angle_rad = (Math.PI / 180) * angle_deg;

  return Array.from({ length: 6 }, (_, i) => {
    const angle = angle_rad * i;
    const x = size + size * Math.cos(angle);
    const y = size + size * Math.sin(angle);
    return `${x},${y}`;
  }).join(" ");
}

class Cell extends React.Component {
  render() {
    const {
      q,
      r,
      onClick,
      selected,
      onDropCard,
      onDragOver,
      children,
    } = this.props;

    const x = q;
    const y = r;
    const left = x * HEX_HORIZ_SPACING + (y % 2) * (HEX_WIDTH / 2);
    const top = y * HEX_VERT_SPACING;
    const size = HEX_SIZE;

    return (
      <svg
        width={HEX_WIDTH}
        height={HEX_HEIGHT}
        style={{
          position: "absolute",
          left: `${left + 300}px`,
          top: `${top + 300}px`,
          cursor: "pointer",
        }}
        onClick={() => onClick(q, r)}
        onDrop={(e) => onDropCard(e, q, r)}
        onDragOver={onDragOver}
      >
        <polygon
          points={getHexPoints(size)}
          fill={selected ? "#0d6efd" : "#fdf089"}
          stroke="black"
          strokeWidth="2"
        />
        {children && (
          <foreignObject
            x={size * 0.5}
            y={size * 0.5}
            width={size}
            height={size}
          >
            <div className="hex-inner">{children}</div>
          </foreignObject>
        )}
      </svg>
    );
  }
}

class Card extends React.Component {
  handleDragStart = (e) => {
    e.dataTransfer.setData("cardId", this.props.id);
  };

  render() {
    return (
      <div
        draggable
        onDragStart={this.handleDragStart}
        className="bg-warning text-dark p-2 rounded shadow me-2"
        style={{ width: 40, height: 40, textAlign: "center" }}
      >
        🃏{this.props.id + 1}
      </div>
    );
  }
}

class Grid extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedCell: null,
      cardPositions: {},
    };
  }

  handleCellClick = (q, r) => {
    this.setState({ selectedCell: { q, r } });
    console.log(`Clicked on cell: (${q}, ${r})`);
  };

  handleDrop = (e, q, r) => {
    e.preventDefault();
    const cardId = e.dataTransfer.getData("cardId");
    if (cardId !== "") {
      this.setState((prevState) => {
        const updated = {
          ...prevState.cardPositions,
          [cardId]: { q, r },
        };
        console.log("Cartas en tablero:", updated);
        return { cardPositions: updated };
      });
    }
  };

  handleDragOver = (e) => {
    e.preventDefault();
  };

  render() {
    const cells = [];
    const grid = generateHexGrid(GRID_RADIUS);

    for (const { q, r } of grid) {
      const isSelected =
        this.state.selectedCell?.q === q &&
        this.state.selectedCell?.r === r;
      const cardHere = Object.entries(this.state.cardPositions).find(
        ([_, pos]) => pos.q === q && pos.r === r
      );

      cells.push(
        <Cell
          key={`${q},${r}`}
          q={q}
          r={r}
          onClick={this.handleCellClick}
          selected={isSelected}
          onDropCard={this.handleDrop}
          onDragOver={this.handleDragOver}
        >
          {cardHere && <Card id={parseInt(cardHere[0])} />}
        </Cell>
      );
    }

    return (
      <div className="m-4" style={{ position: "relative", height: 700 }}>
        <div className="mb-3 d-flex align-items-center">
          <span className="me-3">Arrastra una carta:</span>
          {[...Array(CARD_COUNT)].map(
            (_, i) => !this.state.cardPositions[i] && <Card key={i} id={i} />
          )}
        </div>
        {cells}
      </div>
    );
  }
}

export default class App extends React.Component {
  render() {
    return (
      <div className="container text-center mt-5">
        <h1 className="mb-4">Mapa de Juego en Forma de Panal</h1>
        <Grid />
      </div>
    );
  }
}